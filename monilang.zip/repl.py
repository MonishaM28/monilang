from moni_lang import run_code

print("Welcome to MoniLang REPL. Type 'exit' to quit.")
buffer = []
while True:
    try:
        line = input(">>> ")
        if line.strip().lower() == "exit":
            break
        buffer.append(line)
        if line.strip() == "":
            run_code("\n".join(buffer))
            buffer = []
    except KeyboardInterrupt:
        print("\nExiting REPL.")
        break

# MoniLang 🌀

A **mini programming language** built in Python for fun & learning.  
Supports variables, loops, print statements, and an interactive REPL.

---

## ✨ Features
- `print` statement
- Variables and math (`a = 5`, `a + 1`)
- Loops (`while`)
- REPL mode (`python repl.py`)

---

## 🚀 Quick Start
```bash
# Run a MoniLang program
python moni_lang.py examples/hello.moni

# Run loop example
python moni_lang.py examples/loop.moni

# Start REPL
python repl.py
```

---

## 📂 Example
**hello.moni**
```
print "Hello, MoniLang!"
```
Output:
```
Hello, MoniLang!
```

---

## 📜 License
MIT License – free to use & share.

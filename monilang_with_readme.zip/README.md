# MoniLang - Resume-Friendly README

**MoniLang** is a Python-based mini programming language designed for learning and demonstration purposes. It supports variables, arithmetic, loops, print statements, functions, and an interactive REPL.

## Features
- Print statements
- Variables and math operations
- While loops
- Functions with return
- Interactive REPL
- Example programs included

## Quick Start
1. Run a MoniLang program:
```bash
python moni_lang.py examples/hello.moni
```
Output: `Hello, MoniLang!`

2. Run loop example:
```bash
python moni_lang.py examples/loop.moni
```
Output: `0 1 2 3 4`

3. Start the REPL:
```bash
python repl.py
```
Interactive session: define variables, run loops, test functions.

## License
MIT License

import sys

def run_code(code):
    env = {}
    lines = code.split("\n")
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith("print"):
            to_print = line[len("print"):].strip()
            try:
                print(eval(to_print, {}, env))
            except:
                print(to_print)
        else:
            try:
                exec(line, {}, env)
            except Exception as e:
                print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python moni_lang.py <file.moni>")
        sys.exit(1)
    with open(sys.argv[1]) as f:
        code = f.read()
    run_code(code)
